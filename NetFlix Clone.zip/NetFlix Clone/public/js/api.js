let api_key = "3ba7dfa73dd013c992369695833fa9c1";

let img_url = "https://image.tmdb.org/t/p/w500";
let genres_list_http = "https://api.themoviedb.org/3/genre/movie/list?";
let movies_genres_http = "https://api.themoviedb.org/3/discover/movie?";
let original_img_url = "https://image.tmdb.org/t/p/original";
let movie_genres_http = "https://api.themoviedb.org/3/discover/movie?";
let movie_detail_http = "https://api.themoviedb.org/3/movie";